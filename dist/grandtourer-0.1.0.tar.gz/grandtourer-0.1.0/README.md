# GrandTourer

A MacOS CLI Tool for Easy Application Launch
